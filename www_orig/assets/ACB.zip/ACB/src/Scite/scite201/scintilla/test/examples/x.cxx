// A demonstration program
int main() {
	printf("hello world %d\n", 9);
}
