(use 'clojure.contrib.def)

(defvar- start-metamap-line-p #"^\s*#")
(defvar- end-metamap-line-p   #"^.*}\s*$")
(print "pepe")
(defvar- start-doc-line-p     #"^\s*\"")
(defvar- start-nonmeta-line-p #"^\s*(\[)|(\(\[)")

(defn- take-starting
  "Returns a lazy seq of items in coll starting with the first element for which
  pred returns true"
  [pred coll]
  (drop-while #(not (pred %)) coll))
