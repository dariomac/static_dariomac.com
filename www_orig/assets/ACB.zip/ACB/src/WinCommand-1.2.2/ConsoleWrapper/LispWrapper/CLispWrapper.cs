using System;

namespace CWrapper.LispWrapper
{
	/// <summary>
	/// Summary description for CLispWrapper.
	/// </summary>
	public class CLispWrapper
	{
		public CLispWrapper()
		{
			//
			// TODO: Add constructor logic here
			//
		}

        public static bool IsBalanced(string command)
        {
            // create the scanner to use
            Scanner scanner = new Scanner();

            // create the parser, and supply the scanner it should use
            Parser parser = new Parser(scanner);

            // parse the input. the result is a parse tree.
            ParseTree tree = parser.Parse(command);

            return tree.Errors.Count == 0;
        }

        //public static bool IsBalanced2(string command) {
            

        //    int openCounter=0, closeCounter=0;
        //    for(int i = 0; i<command.Length; i++) {
        //        if(command.Substring(i,1).Equals("("))
        //            openCounter++;
        //        else if(command.Substring(i,1).Equals(")"))
        //            closeCounter++;
        //    }
        //    return (openCounter==closeCounter);
        //}
	}
}
