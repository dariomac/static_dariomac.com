using System;
using System.IO;

namespace CWrapper
{
	/// <summary>
	/// Summary description for Common.
	/// </summary>
	public class Common
	{
		public Common()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
