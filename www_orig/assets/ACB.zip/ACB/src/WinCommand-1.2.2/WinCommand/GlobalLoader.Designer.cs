﻿namespace WinCommand
{
    partial class GlobalLoader
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GlobalLoader));
            this.txtLoader = new System.Windows.Forms.TextBox();
            this.imgExecLoad = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.imgExecLoad)).BeginInit();
            this.SuspendLayout();
            // 
            // txtLoader
            // 
            this.txtLoader.BackColor = System.Drawing.Color.Black;
            this.txtLoader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLoader.Font = new System.Drawing.Font("Lucida Console", 8.25F);
            this.txtLoader.ForeColor = System.Drawing.Color.LawnGreen;
            this.txtLoader.Location = new System.Drawing.Point(0, 0);
            this.txtLoader.Multiline = true;
            this.txtLoader.Name = "txtLoader";
            this.txtLoader.Size = new System.Drawing.Size(332, 138);
            this.txtLoader.TabIndex = 24;
            this.txtLoader.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLoader_KeyDown);
            // 
            // imgExecLoad
            // 
            this.imgExecLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.imgExecLoad.BackColor = System.Drawing.Color.Black;
            this.imgExecLoad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgExecLoad.Image = ((System.Drawing.Image)(resources.GetObject("imgExecLoad.Image")));
            this.imgExecLoad.InitialImage = null;
            this.imgExecLoad.Location = new System.Drawing.Point(315, 121);
            this.imgExecLoad.Name = "imgExecLoad";
            this.imgExecLoad.Size = new System.Drawing.Size(14, 14);
            this.imgExecLoad.TabIndex = 25;
            this.imgExecLoad.TabStop = false;
            this.imgExecLoad.Click += new System.EventHandler(this.imgExecLoad_Click);
            // 
            // GlobalLoader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.imgExecLoad);
            this.Controls.Add(this.txtLoader);
            this.Name = "GlobalLoader";
            this.Size = new System.Drawing.Size(332, 138);
            ((System.ComponentModel.ISupportInitialize)(this.imgExecLoad)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLoader;
        private System.Windows.Forms.PictureBox imgExecLoad;
    }
}
