using System;

namespace WinCommand.SnippetManager
{
	/// <summary>
	/// Definition of an individual code snippet.
	/// </summary>
	public class Snippet
	{
		// Internal field variables
		private string _name;
		private string _code;
		private string _category = "Common";

		// Constructors
		public Snippet() {}
		
		public Snippet(string name, string code) 
		{ 
			_name = name; 
			_code = code; 
		}
		public Snippet(string name, string code, string category) 
		{
			_name = name; 
			_code = code; 
			_category = category;
		}

		// Properties
		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}

		public string Code
		{
			get { return _code; }
			set { _code = value; }
		}
		public string Category
		{
			get { return _category; }
			set { _category = value; }
		}

		public override string ToString()
		{
			return this._name;
		}

	}
}
