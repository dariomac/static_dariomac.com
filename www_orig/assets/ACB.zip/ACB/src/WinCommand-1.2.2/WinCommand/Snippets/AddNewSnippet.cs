using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WinCommand.SnippetManager
{
	/// <summary>
	/// Summary description for AddNewSnippet.
	/// </summary>
	public class AddNewSnippet : System.Windows.Forms.Form
	{
		private CategoryCollection categories;
		private ArrayList snippets;

		private System.Windows.Forms.TextBox textName;
		private System.Windows.Forms.TextBox textSnippet;
		private System.Windows.Forms.Label labelName;
		private System.Windows.Forms.Label labelSnippet;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Label labelCategory;
		private System.Windows.Forms.ComboBox comboBoxCategory;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public AddNewSnippet()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		public CategoryCollection Categories
		{
			get { return categories; }
			set { categories = value; }
		}
		public ArrayList Snippets
		{
			get { return snippets; }
			set { snippets = value; }
		}
		public string SnippetName { get { return textName.Text; } }
		public string SnippetCode { get { return textSnippet.Text; } } 
		public string SnippetCategory 
		{ 
			get 
			{ 
				return (string)comboBoxCategory.SelectedValue;
			} 
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textName = new System.Windows.Forms.TextBox();
			this.labelName = new System.Windows.Forms.Label();
			this.labelSnippet = new System.Windows.Forms.Label();
			this.textSnippet = new System.Windows.Forms.TextBox();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.labelCategory = new System.Windows.Forms.Label();
			this.comboBoxCategory = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// textName
			// 
			this.textName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textName.Font = new System.Drawing.Font("Lucida Console", 8.25F);
			this.textName.Location = new System.Drawing.Point(8, 16);
			this.textName.Name = "textName";
			this.textName.Size = new System.Drawing.Size(248, 18);
			this.textName.TabIndex = 0;
			this.textName.Text = "";
			// 
			// labelName
			// 
			this.labelName.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelName.Location = new System.Drawing.Point(8, 0);
			this.labelName.Name = "labelName";
			this.labelName.Size = new System.Drawing.Size(40, 16);
			this.labelName.TabIndex = 1;
			this.labelName.Text = "&Name:";
			// 
			// labelSnippet
			// 
			this.labelSnippet.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelSnippet.Location = new System.Drawing.Point(8, 96);
			this.labelSnippet.Name = "labelSnippet";
			this.labelSnippet.Size = new System.Drawing.Size(48, 16);
			this.labelSnippet.TabIndex = 5;
			this.labelSnippet.Text = "&Snippet:";
			// 
			// textSnippet
			// 
			this.textSnippet.AcceptsReturn = true;
			this.textSnippet.AcceptsTab = true;
			this.textSnippet.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textSnippet.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textSnippet.Location = new System.Drawing.Point(8, 112);
			this.textSnippet.Multiline = true;
			this.textSnippet.Name = "textSnippet";
			this.textSnippet.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.textSnippet.Size = new System.Drawing.Size(248, 144);
			this.textSnippet.TabIndex = 4;
			this.textSnippet.Text = "";
			// 
			// btnAdd
			// 
			this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnAdd.Location = new System.Drawing.Point(104, 264);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.TabIndex = 6;
			this.btnAdd.Text = "Add";
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnCancel.Location = new System.Drawing.Point(181, 264);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 7;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// labelCategory
			// 
			this.labelCategory.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelCategory.Location = new System.Drawing.Point(8, 48);
			this.labelCategory.Name = "labelCategory";
			this.labelCategory.Size = new System.Drawing.Size(56, 16);
			this.labelCategory.TabIndex = 3;
			this.labelCategory.Text = "&Category:";
			// 
			// comboBoxCategory
			// 
			this.comboBoxCategory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.comboBoxCategory.Font = new System.Drawing.Font("Lucida Console", 8.25F);
			this.comboBoxCategory.Location = new System.Drawing.Point(8, 64);
			this.comboBoxCategory.Name = "comboBoxCategory";
			this.comboBoxCategory.Size = new System.Drawing.Size(248, 19);
			this.comboBoxCategory.TabIndex = 2;
			// 
			// AddNewSnippet
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(344, 298);
			this.Controls.Add(this.comboBoxCategory);
			this.Controls.Add(this.labelCategory);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.textSnippet);
			this.Controls.Add(this.labelSnippet);
			this.Controls.Add(this.labelName);
			this.Controls.Add(this.textName);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.MinimumSize = new System.Drawing.Size(350, 200);
			this.Name = "AddNewSnippet";
			this.ShowInTaskbar = false;
			this.Text = "Add New Snippet";
			this.Load += new System.EventHandler(this.AddNewSnippet_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnAdd_Click(object sender, System.EventArgs e)
		{
			if ((this.textName.Text != String.Empty) && (this.textName.Text != "") && (this.textName.Text != " "))
			{
				bool nameAlreadyTaken = false;
				foreach(Snippet s in snippets)
				{
					if (s.Name == textName.Text)
						nameAlreadyTaken = true;
				}
				if (!nameAlreadyTaken)
				{
					this.DialogResult = DialogResult.OK;
					this.Close();
						
				}
				else
				{
					MessageBox.Show("A snippet with that name already exists. Please choose another name.", "", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					textName.Focus();
					textName.SelectAll();
				}

				
			}
			else
			{
				MessageBox.Show(this, "You must provide a name for the snippet.", "", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				textName.Focus();
				textName.SelectAll();
			}

		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void AddNewSnippet_Load(object sender, System.EventArgs e)
		{
			this.comboBoxCategory.DataSource = categories;
			this.comboBoxCategory.DisplayMember = "Name";
			this.comboBoxCategory.ValueMember = "Name";
		}
	}
}
