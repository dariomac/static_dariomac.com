using System;
using System.Collections;

namespace WinCommand.SnippetManager
{
	/// <summary>
	/// Summary description for Category.
	/// </summary>
	public class Category : ICloneable
	{
		private string _name;

		public Category(string name)
		{
			_name = name;	
		}
		public string Name
		{
			get
			{
				return _name;
			}
			set
			{
				_name = value;
			}
		}
		public object Clone()
		{
			return new Category(_name);
		}
	}
	public class CategoryCollection : CollectionBase, ICloneable
	{
		public CategoryCollection() : base()
		{
		}
		public Category this[int index]
		{
			get
			{
				return (Category)List[index];
			}
		}
		public int Add(Category category)
		{
			return List.Add(category);
		}
		public Category Add(string name)
		{
			Category category = new Category(name);
			this.Add(category);
			return category;
		}
		public void Remove(Category category)
		{
			List.Remove(category);
		}
		public object Clone()
		{
			CategoryCollection c = new CategoryCollection();
			foreach (object item in List)
			{
				c.Add(((Category)item).Name);
			}
			return c;
		}
		public int IndexOf(Category category)
		{
			return List.IndexOf(category);
		}
		public void Insert(int index, Category category)
		{
			List.Insert(index, category);
		}
	}
}
