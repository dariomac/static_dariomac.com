using System;
using System.Text.RegularExpressions;

namespace WinCommand {
	/// <summary>
	/// Summary description for AppConf.
	/// </summary>
	public class AppConf{
		private string _name;
		private string _path;
		private string _arguments;
		private string _endCommand;
		private Regex _promptRegExp;

        public AppConf() { }
	
		public AppConf(string line){
			if(! line.Equals(string.Empty)){
				string[] conf = line.Split('|');
				_name = conf[0];
				_path = conf[1];
				_arguments = conf[2];
				_endCommand = conf[3];
			}
		}

		public Regex PromptRegExp{
			get{
				return _promptRegExp;
			}
			set{
				_promptRegExp = value;
			}
		}

		public string Name{
			get{
				return _name;
			}
            set {
                _name = value;
            }
		}

		public string Path{
			get{
				return _path;
			}
            set {
                _path = value;
            }
		}

		public string Arguments{
			get{
				return _arguments;
			}
            set {
                _arguments = value;
            }
		}

		public string EndCommand{
			get{
				return _endCommand;
			}
            set {
                _endCommand = value;
            }
		}

        public override string ToString() {
			return _name + "|" + _path + "|" + _arguments + "|" + _endCommand;
		}
	}
}
