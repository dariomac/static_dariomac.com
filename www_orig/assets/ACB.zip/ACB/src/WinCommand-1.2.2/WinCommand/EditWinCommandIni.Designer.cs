﻿namespace WinCommand
{
    partial class EditWinCommandIni
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIni = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtIni
            // 
            this.txtIni.BackColor = System.Drawing.Color.Black;
            this.txtIni.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtIni.ForeColor = System.Drawing.Color.LawnGreen;
            this.txtIni.Location = new System.Drawing.Point(0, 0);
            this.txtIni.Multiline = true;
            this.txtIni.Name = "txtIni";
            this.txtIni.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtIni.Size = new System.Drawing.Size(546, 273);
            this.txtIni.TabIndex = 1;
            // 
            // EditWinCommandIni
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 273);
            this.Controls.Add(this.txtIni);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "EditWinCommandIni";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "[WinCommand.ini] - Close to save";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.EditWinCommandIni_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIni;
    }
}