﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;

namespace WinCommand
{
    public partial class EditWinCommandIni : Form
    {
        IniFile _iniFile;

        public EditWinCommandIni()
        {
            InitializeComponent();

            StreamReader sr = File.OpenText(IniFile.INI_FILENAME);
            txtIni.Text = sr.ReadToEnd();
            txtIni.SelectionStart = 0;

            sr.Close();
            sr.Dispose();
        }

        private void EditWinCommandIni_FormClosing(object sender, FormClosingEventArgs e)
        {
            StreamWriter swr = new StreamWriter(IniFile.INI_FILENAME);
            swr.Write(txtIni.Text);
            swr.Close();
            swr.Dispose();
        }
    }
}
