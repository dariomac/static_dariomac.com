using System;
using System.Drawing;
using System.Windows.Forms;
using System.Text;
using System.ComponentModel;
using CWrapper.LispWrapper;
using CWrapper;
using System.Collections;
using System.Threading;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.IO;

namespace WinCommand
{
	public class ShellTextBox : RichTextBox
    {
        #region Constants and Enumerations

        public const string CMD_CLS = "cls";
        public const string CMD_EXITCMD = "exit-cmd";
        public const string CMD_EXIT = "exit";
        public const string CMD_HISTORY = "history";
        public const string CMD_RESTART = "restart";
        public const string CMD_SAVE_CONFIG = "save-config";
        public const string CMD_SAVE_HISTORY = "save-history";
        public const string CMD_START = "start";
        public const string SPACE = " ";
        private const string STR_PROMPT_SYMBOL = ">";

        #endregion

        #region Members Variables

        //Indicates the position of the last character (not include characters of the actual command)
        private int _frozenCaretPosition = 0;

        private CommandHistory commandHistory = new CommandHistory();
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        // cuando est� en true, entra en el WM_PAINT del WndProc
        private bool _paint = true;

        private AppConf _appToStart;
        private string _sysCmdPrefix;
        private bool _isClosing;

        //Wrapper de Consola
        private ConsoleWrapper _cWrapper;

        private enum EventsToHandle
        {
            KeyDown,
            KeyUp,
            KeyPress,
            None
        }

        private enum LineAction
        {
            Add,
            Substract,
            UpdateToLast
        }

        private bool _isMatchChar;

        class CharMatchesConf
        {
            public Font MatchFont;
            public Color MatchColor;
            public char OpenChar;
            public char CloseChar;
        }

        private Dictionary<char, CharMatchesConf> _charMatches = new Dictionary<char, CharMatchesConf>();
#endregion

        #region Events ans Delegates Declaration

        public delegate void StatusUpdatedEventHandler(object sender, StatusUpdatedEventArgs e);
        public event StatusUpdatedEventHandler StatusUpdated;

        public delegate void DebuggerUpdatedEventHandler(object sender, DebuggerUpdatedEventArgs e);
		public event DebuggerUpdatedEventHandler DebuggerUpdated;

        public delegate void EventCommandEnteredEventHandler(object sender, CommandEnteredEventArgs e);
		public event EventCommandEnteredEventHandler CommandEntered;

        public delegate void CmdExitAppEventHandler(object sender, CommandEnteredEventArgs e);
        public event CmdExitAppEventHandler CmdExitExecuted;

        public delegate void CmdKillAppEventHandler(object sender, CommandEnteredEventArgs e);
        public event CmdKillAppEventHandler CmdKillExecuted;

        public delegate void AddTextCallBack(StringBuilder text, bool updateCaretPosition);
        public delegate void UpdatePromptLineCallBack();

        #endregion

        #region Constructor/Destructor

        #region Component Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // ShellTextBox
            // 
            this.AcceptsTab = true;
            this.AllowDrop = true;
            this.BackColor = System.Drawing.Color.Black;
            this.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ForeColor = System.Drawing.Color.LawnGreen;
            this.MaxLength = 0;
            this.Size = new System.Drawing.Size(400, 176);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ShellControl_KeyDown);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.ShellTextBox_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.ShellTextBox_DragEnter);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.shellTextBox_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ShellTextBox_KeyUp);
            this.ResumeLayout(false);

        }

          #endregion

        public ShellTextBox()
        {
            // Set the value of the double-buffering style bits to true.
            /*this.SetStyle(ControlStyles.DoubleBuffer | 
                ControlStyles.UserPaint | 
                ControlStyles.AllPaintingInWmPaint,
                true);
            this.UpdateStyles();
*/

            // This call is required by the Windows.Forms Form Designer.
            InitializeComponent();

            this.DragDrop += new DragEventHandler(ShellTextBox_DragDrop);
            this.DragEnter += new DragEventHandler(ShellTextBox_DragEnter);

            InitializeCharMatchesConf();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
                if (CWrapper != null)
                    CWrapper.Dispose();
            }
            base.Dispose(disposing);
        }

        #endregion

        #region Properties

        public ConsoleWrapper CWrapper {
            get {
                return _cWrapper;
            }
            set {
                _cWrapper = value;
            }
        }

        public bool IsClosing
        {
            get
            {
                return _isClosing;
            }
            set
            {
                _isClosing = value;
            }
        }

#endregion

        #region Public Methods

        #region Edit Methods

        new public void Paste() {
            if (!IsCaretAtWritablePosition())
                MoveCaretToEndOfText();

            // Retrieves the data from the clipboard.
            IDataObject iData = Clipboard.GetDataObject();
            // Determines whether the data is in a format you can use.
            if (iData.GetDataPresent(DataFormats.Text))
            {
                string textToPaste = (String)iData.GetData(DataFormats.Text);
                textToPaste = textToPaste.Replace("\r\n", "\n");
                
                base.Paste();

                SetCurrentLineToBaseFormat();
            }
        }

        new public void Copy() {
            base.Copy();
        }

        new public void Cut() {
            if (!IsCaretAtWritablePosition())
                MoveCaretToEndOfText();
            else
                base.Cut();
        }

        new public void Undo() {
            if (this.IsCaretAtWritablePosition() && !this.IsCaretJustAfterPrompt()) {
                base.Undo();
            }
        }

        new public void Redo() {
            if (this.IsCaretAtWritablePosition() && !this.IsCaretJustAfterPrompt())
            {
                base.Redo();
            }
        }

        public void Clear(string fullClsCommand) {
            string tmpPrompt = Lines[Lines.Length - 1].Replace(fullClsCommand, string.Empty);
            base.Clear();
            WriteText(new StringBuilder(tmpPrompt));
        }

        #endregion

        public void WriteText(StringBuilder text)
        {
            WriteText(text, true);
        }

        public void WriteText(StringBuilder text, bool updateCaretPosition)
        {
            if (InvokeRequired)
                this.Invoke(new AddTextCallBack(AddText), new object[] { text, updateCaretPosition });
            else
                AddText(text, updateCaretPosition);
        }

        public CommandHistory CmdHistory {
			get{
				return commandHistory;
			}
		}

        public void BeginUpdate(){
			_paint = false;
		}

		public void EndUpdate(){
			_paint = true;
		}

		public bool CanPaint{
			get{
				return _paint;
			}
		}

        public void StartConsoleApp(string appToStartName, IniFile conf)
        {
            _appToStart = (AppConf)conf.Applications[appToStartName];

            _sysCmdPrefix = conf.SysCmdPrefix;

            CWrapper = new ConsoleWrapper(_appToStart.Path, _appToStart.EndCommand, true, true, true);

            CWrapper.Arguments = ExpandArguments(_appToStart.Arguments, conf.EnvVariables);
            try
            {
                //Vamos agregando las variables de entorno, haciendo las sustituciones de estas en el path si
                //corresponde.
                foreach (KeyValuePair<String, String> entry in conf.EnvVariables)
                {
                    CWrapper.AddEnvironmentVariable(entry.Key.ToString(), entry.Value.ToString();
                    
                    if (CWrapper.ConsoleAppPath.IndexOf(_sysCmdPrefix + entry.Key) != -1)
                    {
                        CWrapper.ConsoleAppPath = CWrapper.ConsoleAppPath.Replace(_sysCmdPrefix + entry.Key, entry.Value.ToString());
                    }

                    if (CWrapper.Arguments.IndexOf(_sysCmdPrefix + entry.Key) != -1)
                    {
                        CWrapper.Arguments = CWrapper.Arguments.Replace(_sysCmdPrefix + entry.Key, entry.Value.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Environment variable already defined. " + ex.Message);
            }

            CWrapper.StartWrapper(800, conf.BufferLength);

            CWrapper.ConsoleId = _appToStart.Name;

            ThreadStart tOutStart = new ThreadStart(UpdateStdOutText);
            Thread tOut = new Thread(tOutStart);
            tOut.Start();

            ThreadStart tErrStart = new ThreadStart(UpdateStdErrText);
            Thread tErr = new Thread(tErrStart);
            tErr.Start();
        }

        public void EndExecutingApp() {
            WriteText(new StringBuilder(CWrapper.EndCommand));
            CWrapper.KillWrapper();
        }

        public void KillConsole() {
            ProcessInternalCommand(_sysCmdPrefix + ShellTextBox.CMD_EXIT);
        }

        public bool ProcessInternalCommand(string command)
        {
            //Command: cls
            if (command.StartsWith(_sysCmdPrefix + CMD_CLS))
            {
                Clear();
                return true;
            }
            //Command: exit-cmd. Exit the actual running console.
            else if (command.StartsWith(_sysCmdPrefix + CMD_EXITCMD))
            {
                WriteText(new StringBuilder("\nApplication closed.!!!\n\n"));
                OnCmdExitExecuted(command);
                return true;
            }
            //Command: exit. Kill running command window (can be used before program closing)
            else if (command.StartsWith(_sysCmdPrefix + CMD_EXIT))
            {
                if (CWrapper == null || CWrapper.HasExited)
                {
                    //This is to stop the loops inside error and output reading threads
                    IsClosing = true;
                }
                else
                {
                    IsClosing = true;
                    if (CWrapper != null)
                    {
                        CWrapper.KillWrapper();
                        CWrapper.Dispose();
                    }
                }
                return true;
            }
            //Command: history. Print history to the console.
            else if (command.StartsWith(_sysCmdPrefix + CMD_HISTORY))
            {
                string[] commands = CmdHistory.GetCommandHistory();
                StringBuilder stringBuilder = new StringBuilder(commands.Length);
                stringBuilder.Append("\n");
                foreach (string s in commands)
                {
                    stringBuilder.Append(s);
                    stringBuilder.Append("\n");
                }
                WriteText(stringBuilder);

                return true;
            }
            //Restart the running console
            else if (command.StartsWith(_sysCmdPrefix + CMD_RESTART)) {               
                return true;
            }
            else
                return false;
        }
        #endregion

        #region Protected Methods

        // Overridden to protect against deletion of contents
		// cutting the text and deleting it from the context menu
        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                //case 0x0302: //WM_PASTE
                //case 0x0301:
                //case 0x0300: //WM_CUT
                //case 0x000C: //WM_SETTEXT
                //case 0x0303: //WM_CLEAR
                //    return;
                case 0x00f:  //WM_PAINT
                    if (_paint)
                        base.WndProc(ref m);
                    else
                        m.Result = IntPtr.Zero;
                    break;
                default:
                    base.WndProc(ref m);
                    break;
            }
        }

        #endregion

        #region Private Methods

        private bool IsCaretAtWritablePosition()
        {
            return GetCaretPosition() >= _frozenCaretPosition;
        }

        private int[] GetCoordsBetweenStrings(bool verbose) {
            return GetCoordsBetweenStrings(null, null, verbose);
        }

        private int[] GetCoordsBetweenStrings(string open, string close, bool verbose) {
			int[] res = new int[2];
			try {
				int absStartPos = (Text.Length - GetTextAtPrompt().Length) + (GetCaretColumnPosition());

				int backward = -1;
				int forward = -1;
				int tempPos = GetCaretColumnPosition()-1;
				int level = 0;
                string line = GetTextAtPrompt();

                if (open == null && close == null)
                    SearchBackwardInCharMatches(ref open, ref close, verbose, ref backward, tempPos, ref level, line);
                else
                    SearchBackward(open, close, verbose, ref backward, tempPos, ref level, line);
				
				tempPos = GetCaretColumnPosition();

                SearchForward(open, close, ref forward, tempPos, level, line);

				//[StartCoord, Length]
				res[0] = absStartPos - backward;
				res[1] = backward + forward + 1;
			}
			catch {
				if(verbose)
					OnStatusUpdated(new StatusUpdatedEventArgs("Unbalanced command. I can't select it."));
			}
			return res;
		}

		private void SearchBackwardInCharMatches(ref string open, ref string close, bool verbose, ref int backward, int tempPos, ref int level, string line) {
            while (backward == -1)
            {
                char lSub = line.Substring(tempPos, 1).ToCharArray()[0];

                if (_charMatches.ContainsKey(lSub))
                {
                    open = _charMatches[lSub].OpenChar.ToString();
                    close = _charMatches[lSub].CloseChar.ToString();

                    if (open.Equals(lSub.ToString()))
                    {
                        if (level == 0)
                        {
                            backward = Math.Abs(GetCaretColumnPosition() - tempPos);
                        }
                        else level--;
                    }
                    else if (close.Equals(lSub.ToString()))
                    {
                        level++;
                    }
                }
                //else if(line.Substring(tempPos,1).Equals(close)) level++;
                else if (line.Substring(tempPos, 1).Equals(STR_PROMPT_SYMBOL))
                {
                    if (verbose)
                        OnStatusUpdated(new StatusUpdatedEventArgs("Moving to the left we reach the prompt.!!!"));
                }
                tempPos--;
            }
		}

        private void SearchBackward(string open, string close, bool verbose, ref int backward, int tempPos, ref int level, string line)
        {
            while (backward == -1)
            {
                if (line.Substring(tempPos, 1).Equals(open))
                {
                    if (level == 0)
                    {
                        backward = Math.Abs(GetCaretColumnPosition() - tempPos);
                    }
                    else level--;
                }
                else if (line.Substring(tempPos, 1).Equals(close)) level++;
                else if (line.Substring(tempPos, 1).Equals(STR_PROMPT_SYMBOL))
                {
                    if (verbose)
                        OnStatusUpdated(new StatusUpdatedEventArgs("Moving to the left we reach the prompt.!!!"));
                }
                tempPos--;
            }
        }

		private void SearchForward(string open, string close, ref int forward, int tempPos, int level, string line) {
			while(forward == -1) {
				if(line.Substring(tempPos,1).Equals(close)) {
					if(level == 0) {
						forward = Math.Abs(GetCaretColumnPosition() - tempPos);
					}
					else level--;
				}
				else if(line.Substring(tempPos,1).Equals(open)) level++;
				tempPos++;
			}
		}

		public void SelectBetweenPairs() {
			int[] selectCoords = GetCoordsBetweenStrings(true);
			SelectionStart = selectCoords[0];
			SelectionLength = selectCoords[1];
		}

        private void ShowParentheses()
        {
			char rightChar = ' ';
			char leftChar = ' ';
            CharMatchesConf lMatchConf = null;
			int caretCol = GetCaretColumnPosition();
			int caretPos = GetCaretPosition();
			string currLine = GetTextAtPrompt();

			if(currLine.Length > 0) {
				
				if(IsCaretJustAfterPrompt()) {
					//cuando est� solo el prompt
					if(caretCol != currLine.Length)
						rightChar = char.Parse(currLine.Substring(caretCol,1));
				}
				else if(caretCol > 0 && caretCol == currLine.Length)
					//Caret al final de la l�nea
					leftChar = char.Parse(currLine.Substring(caretCol-1,1));
				else if(caretCol >=0 && caretCol-1 >=0) {
					//Resto de los casos
					rightChar = char.Parse(currLine.Substring(caretCol,1));
					leftChar = char.Parse(currLine.Substring(caretCol-1,1));
				}

				if(caretCol >=0 && caretCol-1 >=0) {
                    if (_charMatches.ContainsKey(leftChar))
                        lMatchConf = _charMatches[leftChar];
                    else if (_charMatches.ContainsKey(rightChar))
                        lMatchConf = _charMatches[rightChar];

                    SetCurrentLineToBaseFormat();

                    if (lMatchConf == null)
                    {
                        //Dejamos el cursor en la posici�n que estaba
                        Select(caretPos, 0);
                        return;
                    }

					SelectParenthesesIfNearCaret(rightChar, leftChar, caretPos, lMatchConf);
	
					//Change the format of parentheses
					ChageParenthesesColour(lMatchConf);

					//Dejamos el cursor en la posici�n que estaba
					Select(caretPos, 0);
				}
				else{
					SetCurrentLineToBaseFormat();
				}
			}
		}

        private void SelectParenthesesIfNearCaret(char rightChar, char leftChar, int caretPos, CharMatchesConf matchConf)
        {
            if (rightChar.Equals(matchConf.OpenChar))
                Select(caretPos + 1, 0);
            if (rightChar.Equals(matchConf.CloseChar))
                Select(caretPos, 0);
            if (leftChar.Equals(matchConf.CloseChar))
                Select(caretPos - 1, 0);
            if (leftChar.Equals(matchConf.OpenChar))
                Select(caretPos, 0);
		}

		private void ChageParenthesesColour(CharMatchesConf matchConf) {          
			int[] selectCoords = GetCoordsBetweenStrings(matchConf.OpenChar.ToString(),matchConf.CloseChar.ToString(),false);
			if(selectCoords[0]!=0 && selectCoords[1]!=0) {
				Select(selectCoords[0],1);
				SelectionColor = matchConf.MatchColor;
				SelectionFont = matchConf.MatchFont;
                
				Select(selectCoords[0] + selectCoords[1] - 1,1);
                SelectionColor = matchConf.MatchColor;
                SelectionFont = matchConf.MatchFont;
			}
		}

        /// <summary>
        /// Return the text after de prompt
        /// </summary>
        /// <returns></returns>
        private string GetTextAtPrompt()
        {
            return Text.Substring(_frozenCaretPosition);
        }

        private void SetCurrentLineToBaseFormat(){
			string currLine = GetTextAtPrompt();

            int selStart = SelectionStart;
            int selLength = SelectionLength;

			int tempCaretPos = GetCaretPosition();
			SelectionStart = Text.Length - currLine.Length;
			SelectionLength = currLine.Length;
			SelectionColor = Color.LawnGreen;
			SelectionFont = Common.CONSOLE_FONT;
			SelectionAlignment = HorizontalAlignment.Left;
			SelectionIndent = 0;
			SelectionHangingIndent = 0;
            if (selLength > 0)
            {
                SelectionStart = selStart;
                SelectionLength = selLength;
            }
            else
                Select(tempCaretPos, 0);
		}

        /// <summary>
        /// Replace the text after de prompt
        /// </summary>
        /// <param name="text">Text to replace</param>
        private void ReplaceTextAtPrompt(String text)
        {
            if (text != null)
            {
                string currentLine = GetTextAtPrompt();
                int charactersAfterPrompt = Text.Length - _frozenCaretPosition;

                if (charactersAfterPrompt == 0)
                    WriteText(new StringBuilder(text), false);
                else
                {
                    Select(TextLength - charactersAfterPrompt, charactersAfterPrompt);
                    SelectedText = text;
                }
            }
        }

        public void MoveCaretToEndOfText()
        {
            BeginUpdate();
            Focus();
            ScrollToCaret();
            Select(TextLength, 0);
            EndUpdate();
            Application.DoEvents();
        }

        #region Predicates

        private int GetCaretColumnPosition()
        {
            string currentLine = GetTextAtPrompt();
            return (GetCaretPosition() - TextLength + currentLine.Length);
        }

        private int GetCaretPosition()
        {
            return SelectionStart;
        }

        private bool IsCaretAtCurrentLine()
        {
            return TextLength - SelectionStart <= GetTextAtPrompt().Length;
        }

        private bool IsCaretJustAfterPrompt()
        {
            return IsCaretAtCurrentLine() && GetCaretPosition() == _frozenCaretPosition;
        }

        private bool IsEditionKey(KeyEventArgs key)
        {
            if (key.Control && key.KeyCode == Keys.V) return true;
            if (key.Control && key.KeyCode == Keys.C) return true;
            if (key.Control && key.KeyCode == Keys.X) return true;
            return false;
        }

        private bool IsCaretKey(KeyEventArgs key)
        {
            if (key.KeyCode == Keys.Up) return true;
            if (key.Control && key.KeyCode == Keys.Up) return true;
            if (key.Shift && key.KeyCode == Keys.Up) return true;

            if (key.KeyCode == Keys.Down) return true;
            if (key.Control && key.KeyCode == Keys.Down) return true;
            if (key.Shift && key.KeyCode == Keys.Down) return true;

            if (key.KeyCode == Keys.Left) return true;
            if (key.Shift && key.KeyCode == Keys.Left) return true;

            if (key.KeyCode == Keys.Right) return true;
            if (key.Control && key.KeyCode == Keys.Right) return true;
            if (key.Shift && key.KeyCode == Keys.Right) return true;

            if (key.KeyCode == Keys.PageUp) return true;
            if (key.Shift && key.KeyCode == Keys.PageUp) return true;
            if (key.KeyCode == Keys.PageDown) return true;
            if (key.Shift && key.KeyCode == Keys.PageDown) return true;

            if (key.KeyCode == Keys.Home) return true;
            if (key.Shift && key.KeyCode == Keys.Home) return true;
            if (key.KeyCode == Keys.End) return true;
            if (key.Shift && key.KeyCode == Keys.End) return true;

            return false;
        }

#endregion
        
        private void PrintLine()
        {
            WriteText(new StringBuilder("\n"), false);
        }

        /// <summary>
        /// Use only from the AddTextCallback
        /// </summary>
        /// <param name="text"></param>
        private void AddText(StringBuilder text, bool updateCaretPosition)
        {
            AppendText(text.ToString());
            MoveCaretToEndOfText();
            if (updateCaretPosition)
                _frozenCaretPosition = GetCaretPosition();
        }

        private void SendDebugMessage(){
			string debugMsg = string.Empty;
			debugMsg += "CaretColPos=" + GetCaretColumnPosition() + ";";
			OnDebbugerUpdated(new DebuggerUpdatedEventArgs(debugMsg));
		}

        private void UpdateStdOutText()
        {
            StringBuilder outTextToWrite = new StringBuilder();

            while (!IsClosing)
            {
                if (CWrapper.HasExited)
                {
                    ProcessInternalCommand(_sysCmdPrefix + ShellTextBox.CMD_EXITCMD);
                    Application.ExitThread();
                    break;
                }
                else
                {
                    if (CWrapper.NextStdOuputIsAvailable())
                    {
                        Monitor.Enter(CWrapper);
                        try
                        {
                            char cChar = CWrapper.ReadCharFromStdOut(true);
                            outTextToWrite.Append(cChar);

                        }
                        finally
                        {
                            Monitor.Exit(CWrapper);
                        }
                    }
                    else
                    {
                        WriteText(outTextToWrite);

                        //limpiamos las variables temporales
                        outTextToWrite = new StringBuilder();
                        CWrapper.DiscardBufferedStdOutData();

                        CWrapper.ReadStdOutBuffer(false);
                    }
                    Application.DoEvents();
                }
            }
            if (IsClosing)
            {
                ProcessInternalCommand(_sysCmdPrefix + ShellTextBox.CMD_EXIT);
            }
        }

        private void UpdateStdErrText()
        {
            StringBuilder errTextToWrite = new StringBuilder();

            while (!IsClosing)
            {
                if (CWrapper.HasExited)
                {
                    Application.ExitThread();
                    break;
                }
                else
                {
                    if (CWrapper.NextStdErrIsAvailable())
                    {
                        Monitor.Enter(CWrapper);
                        try
                        {
                            char cChar = CWrapper.ReadCharFromStdErr(true);
                            errTextToWrite.Append(cChar);
                        }
                        finally
                        {
                            Monitor.Exit(CWrapper);
                        }
                    }
                    else
                    {
                        if (errTextToWrite.Length != 0)
                        {
                            OnStatusUpdated(new StatusUpdatedEventArgs(errTextToWrite.ToString()));

                            //limpiamos las variables temporales
                            errTextToWrite = new StringBuilder();
                            CWrapper.DiscardBufferedStdErrData();
                        }

                        CWrapper.ReadStdErrBuffer(false);
                    }
                    Application.DoEvents();
                }
            }
        }
        #endregion

        #region Events Handlers

        private void ShellControl_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                BeginUpdate();

                ShellTextBox.EventsToHandle eventsToHandle = EventsToHandle.KeyDown;

                //Handles Tools keys
                if (Keys_ToolsHandler(sender, e, eventsToHandle)) return;

                // Handle backspace
                if (Keys_BackspaceHandler(sender, e, eventsToHandle)) return;

                //Handle delete
                if (Keys_DeleteHandler(sender, e, eventsToHandle)) return;

                //Handle Caret position
                if (Keys_CaretHandler(sender, e, eventsToHandle)) return;

                //Handle enter
                if (Keys_EnterHandler(sender, e, eventsToHandle)) return;

                //Handle Match Keys
                if (Keys_MatchKeyHandler(sender, e, eventsToHandle)) return;
            }
            finally
            {
                EndUpdate();
            }
        }

        private void shellTextBox_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            BeginUpdate();

            if (IsCaretAtWritablePosition())
            {
                if (_charMatches.ContainsKey(e.KeyChar))
                    _isMatchChar = true;
                else
                {
                    SetCurrentLineToBaseFormat();
                }
            }
            else{
                MoveCaretToEndOfText();
            }

            EndUpdate();
        }

        private void ShellTextBox_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            try
            {
                BeginUpdate();
                
                ShellTextBox.EventsToHandle eventsToHandle = EventsToHandle.KeyUp;
                
                //Handles Tools keys
                if (Keys_ToolsHandler(sender, e, eventsToHandle)) return;

                // Handle backspace
                if (Keys_BackspaceHandler(sender, e, eventsToHandle)) return;

                //Handle delete
                if (Keys_DeleteHandler(sender, e, eventsToHandle)) return;

                //Handle Caret position
                if (Keys_CaretHandler(sender, e, eventsToHandle)) return;

                //Handle enter
                if (Keys_EnterHandler(sender, e, eventsToHandle)) return;

                //Handle Match Keys
                if (Keys_MatchKeyHandler(sender, e, eventsToHandle)) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        
        void ShellTextBox_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                StringBuilder path = new StringBuilder(((string[])e.Data.GetData(DataFormats.FileDrop))[0]);
                WriteText(path, false);
            }
        }

        void ShellTextBox_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Link;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }
        #endregion

        #region Event redirectors

        protected virtual void OnStatusUpdated(StatusUpdatedEventArgs e)
        {
            if (StatusUpdated != null)
                StatusUpdated(this, e);
        }

        protected virtual void OnDebbugerUpdated(DebuggerUpdatedEventArgs e)
        {
            if (DebuggerUpdated != null)
                DebuggerUpdated(this, e);
        }

        protected virtual void OnCommandEntered(string command)
        {
                BeginUpdate();
                if (!ProcessInternalCommand(command) && CWrapper != null && !CWrapper.HasExited)
                {
                    Monitor.Enter(CWrapper);
                    try
                    {
                        CWrapper.WriteLineToStdInput(command);
                        CWrapper.Wait(100);
                    }
                    finally
                    {
                        Monitor.Exit(CWrapper);
                    }
                }
                else
                {
                    if (IsClosing && CWrapper != null)
                    {
                        CWrapper.KillWrapper();
                    }
                }
                EndUpdate();

                if (CommandEntered != null)
                {
                    CommandEntered(command, new CommandEnteredEventArgs(command));
                }

                if(_isClosing)
                    OnCmdKillExecuted(command);
        }

        protected virtual void OnCmdExitExecuted(string command)
        {
            if (CmdExitExecuted != null)
                CmdExitExecuted(this, new CommandEnteredEventArgs(command));
        }

        protected virtual void OnCmdKillExecuted(string command) {
            if (CmdKillExecuted != null)
                CmdKillExecuted(this, new CommandEnteredEventArgs(command));
        }

        #endregion

        #region Helpers

        private bool Keys_ToolsHandler(object sender, EventArgs e, EventsToHandle eToHandle)
        {
            KeyEventArgs k = (KeyEventArgs)e;

            if (k.Control && k.KeyCode == Keys.B)
            {
                if (eToHandle == EventsToHandle.KeyDown)
                {
                    SelectBetweenPairs();
                    k.Handled = true;

                    return true;
                }
            }

			return false;
		}

        private bool Keys_BackspaceHandler(object sender, KeyEventArgs e, EventsToHandle eToHandle)
        {
            KeyEventArgs k = (KeyEventArgs)e;

            if (k.KeyCode == Keys.Back)
            {
                if (IsCaretAtWritablePosition())
                {
                    if (eToHandle == EventsToHandle.KeyDown)
                    {
                        if (IsCaretJustAfterPrompt())
                        {
                            k.Handled = true;
                        }
                    }
                    else if (eToHandle == EventsToHandle.KeyUp)
                    {
                        ShowParentheses();
                    }
                }
                else
                {
                    MoveCaretToEndOfText();
                    k.Handled = true;
                }

                return true;
            }

            return false;
		}

        private bool Keys_DeleteHandler(object sender, EventArgs e, EventsToHandle eToHandle)
        {
            KeyEventArgs k = (KeyEventArgs)e;

            if (k.KeyCode == Keys.Delete)
            {
                if (IsCaretAtWritablePosition())
                {
                    if (eToHandle == EventsToHandle.KeyUp)
                        ShowParentheses();
                }
                else
                {
                    MoveCaretToEndOfText();
                    k.Handled = true;
                }

                return true;
            }
            
            return false;
        }

        private bool Keys_MatchKeyHandler(object sender, EventArgs e, EventsToHandle eToHandle)
        {
            KeyEventArgs k = (KeyEventArgs)e;

            if (_isMatchChar)
            {
                if (eToHandle == EventsToHandle.KeyUp)
                {
                    ShowParentheses();
                    _isMatchChar = false;
                }

                return true;
            }

            return false;
        }

		private bool Keys_EnterHandler(object sender, EventArgs e, EventsToHandle eToHandle) {
			KeyEventArgs k = (KeyEventArgs)e;

			if (k.KeyCode == Keys.Enter) {
				if(IsCaretAtWritablePosition()) {
					if(eToHandle == EventsToHandle.KeyDown) {
						string currentCommand = GetTextAtPrompt();

						if(CLispWrapper.IsBalanced(currentCommand)) {
							if (currentCommand.Length != 0) {
								SetCurrentLineToBaseFormat();

								currentCommand = currentCommand.Replace("\r\n","\n").Replace("\r","\n");
								OnCommandEntered(currentCommand);

								commandHistory.Add(currentCommand);
							}
						}

						PrintLine();

						k.Handled = true;
					}
				}
				else{
					MoveCaretToEndOfText();
					k.Handled = true;
				}
				return true;
			}
				
            return false;
		}

        private bool Keys_CaretHandler(object sender, EventArgs e, EventsToHandle eToHandle)
        {
            KeyEventArgs k = (KeyEventArgs)e;

            if (IsCaretKey(k))
            {
                if (eToHandle == EventsToHandle.KeyDown)
                {
                    switch (k.KeyCode)
                    {
                        case Keys.Left:
                            break;
                        case Keys.Down:
                            if (k.Control)
                            {
                                if (commandHistory.IsEmpty) { 
                                    k.Handled = true; 
                                    return true; 
                                }
                                if (commandHistory.DoesNextCommandExist)
                                    ReplaceTextAtPrompt(commandHistory.NextCommand);
                                else
                                    ReplaceTextAtPrompt(commandHistory.LastCommand);

                                k.Handled = true;
                            }
                            break;

                        case Keys.Up:
                            if (k.Control)
                            {
                                if (commandHistory.IsEmpty) { 
                                    k.Handled = true; 
                                    return true; 
                                }
                                if (commandHistory.DoesPreviousCommandExist)
                                    ReplaceTextAtPrompt(commandHistory.PreviousCommand);
                                else
                                    ReplaceTextAtPrompt(commandHistory.LastCommand);
                                
                                k.Handled = true;
                            }
                            break;
                        case Keys.Right:
                            if (k.Control)
                            {
                                if (commandHistory.IsEmpty) { 
                                    k.Handled = true; 
                                    return true; 
                                }
                                // Performs command completion
                                string currentTextAtPrompt = GetTextAtPrompt();
                                string lastCommand = commandHistory.LastCommand;

                                if (lastCommand != null && (currentTextAtPrompt.Length == 0 || lastCommand.StartsWith(currentTextAtPrompt)))
                                {
                                    if (lastCommand.Length > currentTextAtPrompt.Length)
                                        WriteText(new StringBuilder(lastCommand.Substring(currentTextAtPrompt.Length,1)),false);
                                }
                            }
                            break;
                        case Keys.Home:
                            break;
                        case Keys.End:
                            break;
                    }

                    return true;
                }
                else if (eToHandle == EventsToHandle.KeyUp)
                {
                    if (SelectedText.Length == 0) ShowParentheses();
                    return true;
                }
                else
                    return false;
            }
               
            return false;
        }

        private void InitializeCharMatchesConf()
        {
            CharMatchesConf parenConf = new CharMatchesConf();
            parenConf.MatchColor = Color.Red;
            parenConf.MatchFont = Common.PARENTHESES_FONT;
            parenConf.OpenChar = '(';
            parenConf.CloseChar = ')';
            _charMatches.Add(parenConf.OpenChar, parenConf);
            _charMatches.Add(parenConf.CloseChar, parenConf);

            CharMatchesConf bracketConf = new CharMatchesConf();
            bracketConf.MatchColor = Color.Blue;
            bracketConf.MatchFont = Common.PARENTHESES_FONT;
            bracketConf.OpenChar = '[';
            bracketConf.CloseChar = ']';
            _charMatches.Add(bracketConf.OpenChar, bracketConf);
            _charMatches.Add(bracketConf.CloseChar, bracketConf);

            CharMatchesConf bracesConf = new CharMatchesConf();
            bracesConf.MatchColor = Color.Yellow;
            bracesConf.MatchFont = Common.PARENTHESES_FONT;
            bracesConf.OpenChar = '{';
            bracesConf.CloseChar = '}';
            _charMatches.Add(bracesConf.OpenChar, bracesConf);
            _charMatches.Add(bracesConf.CloseChar, bracesConf);
        }

        private string ExpandArguments(string arguments, Dictionary<String, String> envVariables)
        {
            //[expand-resource($WCMD-HOME\usr\lib\, *.jar)]
            Regex expansionRegex = new Regex(@"\[expand-resource\(""(.+)"",""(.+)"",""(.+)""\)\]");
            Match expansionRegexMatch = expansionRegex.Match(arguments);

            if (expansionRegexMatch.Groups.Count != 4)
                return arguments;

            string path = expansionRegexMatch.Groups[1].Value;

            foreach (KeyValuePair<String, String> entry in envVariables)
            {
                path = path.Replace(_sysCmdPrefix + entry.Key, entry.Value).Trim();    
            }
            
            string pattern = expansionRegexMatch.Groups[2].Value.Trim();
            string delimiter = expansionRegexMatch.Groups[3].Value.Trim();

            string[] matchedFiles = Directory.GetFiles(path, pattern);
            if (matchedFiles.Length == 0)
                return expansionRegex.Replace(arguments, string.Empty);


            StringBuilder expandedArgument = new StringBuilder();

            foreach (string matchedFile in matchedFiles)
            {
                if (expandedArgument.Length != 0)
                    expandedArgument.Append(delimiter);

                expandedArgument.Append(matchedFile);
            }

            return expansionRegex.Replace(arguments, expandedArgument.ToString());
        }

        #endregion
	}
}
