﻿using System;
using System.Collections;
using System.Text;
using System.IO;

namespace WinCommand
{
	public class CommandHistory
	{
		private int currentPosn;
		private string lastCommand;
		private ArrayList commandHistory = new ArrayList();

		public CommandHistory()
		{
		}

		public void Add(string command)
		{
            //DEPRECATED
			//if (command != lastCommand)
			//{
				commandHistory.Add(command);
				lastCommand = command;
			//}

            //Lo siguiente tendria que ser opcional (configurado desde el ini)
			currentPosn = commandHistory.Count;
		}

		public bool DoesPreviousCommandExist
		{
			get{
				return currentPosn > 0;
			}
		}

		public bool DoesNextCommandExist
		{
			get{
				return currentPosn < commandHistory.Count - 1;
			}
		}

		public string PreviousCommand
		{
			get{
				if(currentPosn!=0){
					lastCommand = (string)commandHistory[--currentPosn];
				}
				else{
					lastCommand = (string)commandHistory[0];
				}
				return lastCommand;
			}
		}

		public string NextCommand
		{
			get{
				if(currentPosn!=commandHistory.Count-1){
					lastCommand = (string)commandHistory[++currentPosn];
				}
				else{
					lastCommand = (string)commandHistory[commandHistory.Count-1];
				}
				return LastCommand;
			}
		}

		public string LastCommand
		{
			get { return lastCommand; }
		}

		public bool IsEmpty {
			get
			{
				return (commandHistory.Count == 0);
			}
		}

		public string[] GetCommandHistory()
		{
			return (string[])commandHistory.ToArray(typeof(string));
		}

		public void SaveHistoryToFile(string path){
			StreamWriter sw = new StreamWriter(path, false);
			foreach (string cmd in commandHistory){
				sw.WriteLine(cmd);
			}
			sw.Close();
		}

		public void ClearHistory(){
			commandHistory.Clear();
		}
	}
}
