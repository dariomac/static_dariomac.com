using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WinCommand
{
	/// <summary>
	/// Summary description for About.
	/// </summary>
	public class About : System.Windows.Forms.Form
	{
		private System.Windows.Forms.RichTextBox txtAbout;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public About()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(About));
			this.txtAbout = new System.Windows.Forms.RichTextBox();
			this.SuspendLayout();
			// 
			// txtAbout
			// 
			this.txtAbout.BackColor = System.Drawing.Color.Black;
			this.txtAbout.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtAbout.ForeColor = System.Drawing.Color.LawnGreen;
			this.txtAbout.Location = new System.Drawing.Point(0, 0);
			this.txtAbout.Name = "txtAbout";
			this.txtAbout.Size = new System.Drawing.Size(456, 253);
			this.txtAbout.TabIndex = 0;
			this.txtAbout.Text = "";
			// 
			// About
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(456, 253);
			this.Controls.Add(this.txtAbout);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "About";
			this.ShowInTaskbar = false;
			this.Text = "WinCommand - About";
			this.Load += new System.EventHandler(this.About_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void About_Load(object sender, System.EventArgs e) {
			txtAbout.Text += "WinCommand \r\n";

			txtAbout.Text += "Copyright (c) 2006-2009 - Dar�o Macchi \r\n";
			txtAbout.Text += "Version: 1.2.2 \r\n";
			txtAbout.Text += "Contact: dariomac@gmail.com \r\n";
			txtAbout.Text += "\r\n";

            txtAbout.Text += "History: \r\n";
            txtAbout.Text += "\r\n";
            txtAbout.Text += "Version 1.2.2: \r\n";
            txtAbout.Text += "\t - add expand-resource in wincommand.ini. \r\n";
            txtAbout.Text += "\r\n";

			txtAbout.Text += "History: \r\n";
			txtAbout.Text += "\r\n";
            txtAbout.Text += "Version 1.2.1: \r\n";
            txtAbout.Text += "\t - Many internal improvements. \r\n";
            txtAbout.Text += "\t - Snippets manager. \r\n";
            txtAbout.Text += "\t - Clojure updates to handle array and hash delimiters ([,],{,}). \r\n";
            txtAbout.Text += "\r\n";

			txtAbout.Text += "Version 1.2.0: \r\n";
			txtAbout.Text += "\t - Run any application configured in WinCommand.ini file. \r\n";
			txtAbout.Text += "\t - Prompt for differents application can be configured. \r\n";
			txtAbout.Text += "\t - Internal commands prefix can be configured. \r\n";
			txtAbout.Text += "\t - Environment variables can be set in configuration file. \r\n";
			txtAbout.Text += "\t - Remember the position of the window. \r\n";
			txtAbout.Text += "\t - Console text can be saved to a file. \r\n";
			txtAbout.Text += "\t - History can be saved to a file. \r\n";
			txtAbout.Text += "\t - History can be cleaned. \r\n";
			txtAbout.Text += "\t - $history command added. \r\n";
			txtAbout.Text += "\r\n";

			txtAbout.Text += "Version 1.1.0: \r\n";
			txtAbout.Text += "\t - Stability was improved. \r\n";
			txtAbout.Text += "\t - Can execute commands with any number if lines. \r\n";
			txtAbout.Text += "\t - Standard output redirected to Status console. \r\n";
			txtAbout.Text += "\t - $exit command added. \r\n";
			txtAbout.Text += "\t - Bugs fixed. \r\n";
			txtAbout.Text += "\r\n";

			txtAbout.Text += "Version 1.0.0: \r\n";
			txtAbout.Text += "\t - Only run CLisp. \r\n";
			txtAbout.Text += "\t - Show colorized parenthesis when match. \r\n";
			txtAbout.Text += "\t - Can execute one line commands. \r\n";
			txtAbout.Text += "\r\n";

			txtAbout.Select(0, "WinCommand \r\n".Length-2);
			txtAbout.SelectionFont = new Font(txtAbout.Font.FontFamily, 10, FontStyle.Bold);
			txtAbout.Select(0, 0);
		}
	}
}
