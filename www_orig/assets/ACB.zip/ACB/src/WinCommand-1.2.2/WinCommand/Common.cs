using System;
using System.Drawing;

namespace WinCommand
{
	/// <summary>
	/// Summary description for Common.
	/// </summary>
	public class Common
	{
		public static readonly Font CONSOLE_FONT = new Font("Lucida Console", (float)8.25, FontStyle.Regular, GraphicsUnit.Point);
		public static readonly Font PARENTHESES_FONT = new Font("Lucida Console",(float)8.25,FontStyle.Underline, GraphicsUnit.Point);
		
		//--------------------------------------------------------------------------
		//     API: LockWindowUpdate
		// Purpose: Locks or Unlocks a window
		[System.Runtime.InteropServices.DllImport("user32")]
		private static extern int LockWindowUpdate(IntPtr hwndLock);
		
		public static void LockControlUpdate(IntPtr handle){
			LockWindowUpdate(handle);
		}

		public static void UnLockControlUpdate(){
			LockWindowUpdate(IntPtr.Zero);
		}
	}
}
