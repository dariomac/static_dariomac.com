﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace WinCommand
{
    public partial class GlobalLoader : UserControl
    {
        private ShellTextBox _shWinCmdToExecute;

        public GlobalLoader()
        {
            InitializeComponent();
        }

        public ShellTextBox WinCmdToExecute
        {
            get
            {
                return _shWinCmdToExecute;
            }
            set
            {
                if (_shWinCmdToExecute == value)
                    return;
                _shWinCmdToExecute = value;
            }
        }

        private void txtLoader_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                ExecGlobalLoader();
            }
        }

        public void ExecGlobalLoader()
        {
            if (_shWinCmdToExecute == null) return;
            if (txtLoader.Text.Equals(string.Empty)) return;
            if (!_shWinCmdToExecute.CWrapper.IsStarted) return;

            _shWinCmdToExecute.WriteText(new StringBuilder(txtLoader.Text + "\r\n"));
            _shWinCmdToExecute.CWrapper.WriteLineToStdInput(txtLoader.Text.Trim());
        }

        private void imgExecLoad_Click(object sender, EventArgs e)
        {
            ExecGlobalLoader();
        }
    }
}
