using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;

namespace WinCommand
{
    public class IniFile
    {
        public const string INI_FILENAME = "WinCommand.ini";

        private Point _location;
        private bool _alwaysOnTop;
        private Dictionary<String, String> _envVariables = new Dictionary<String, String>();
        private string _sysCmdPrefix;
        private int _bufferLength;
        private Dictionary<String, AppConf> _applications;

        private List<string> _iniLines;

        private enum MenuHeader
        {
            None,
            Applications,
            Setup,
            Environment
        }

        /// <summary>
        /// Initializes a new instance of the IniFile class.
        /// </summary>
        public IniFile()
        {
            _applications = new Dictionary<String, AppConf>();
            _iniLines = new List<string>();
        }

        public Dictionary<String, String> EnvVariables
        {
            get
            {
                return _envVariables;
            }
            set
            {
                _envVariables = value;
            }
        }

        public Dictionary<String, AppConf> Applications
        {
            get
            {
                return _applications;
            }
            set
            {
                _applications = value;
            }
        }

        public string SysCmdPrefix
        {
            get
            {
                return _sysCmdPrefix;
            }
            set
            {
                if (_sysCmdPrefix == value)
                    return;
                _sysCmdPrefix = value;
            }
        }
        public int BufferLength
        {
            get
            {
                return _bufferLength;
            }
            set
            {
                if (_bufferLength == value)
                    return;
                _bufferLength = value;
            }
        }

        public bool AlwaysOnTop
        {
            get
            {
                return _alwaysOnTop;
            }
            set
            {
                _alwaysOnTop = value;
            }
        }

        public Point Location
        {
            get
            {
                return _location;
            }
            set
            {
                _location = value;
            }
        }

        public void Load()
        {
            StreamReader sr = File.OpenText(INI_FILENAME);
            String line = sr.ReadLine();
            MenuHeader mh = MenuHeader.None;
            while (line != null)
            {
                if (!line.StartsWith("#"))
                {
                    switch (line)
                    {
                        case "[applications]":
                            mh = MenuHeader.Applications;
                            break;
                        case "[environment]":
                            mh = MenuHeader.Environment;
                            break;
                        case "[setup]":
                            mh = MenuHeader.Setup;
                            break;
                        case "":
                            break;
                        default:
                            switch (mh)
                            {
                                case MenuHeader.Applications:
                                    AppConf app = new AppConf(line);
                                    _applications.Add(app.Name, app);
                                    break;
                                case MenuHeader.Environment:
                                    int indexOfEqualChar = line.IndexOf('=');
                                    string variableValue = line.Substring(indexOfEqualChar + 1);
                                    if (variableValue.StartsWith("%") && variableValue.EndsWith("%"))
                                        variableValue = Environment.GetEnvironmentVariable(variableValue.Replace("%", string.Empty));

                                    _envVariables.Add(line.Substring(0, indexOfEqualChar), variableValue);

                                    break;
                                case MenuHeader.Setup:
                                    if (line.StartsWith("main.window.position="))
                                    {

                                        string main_wnd_pos = line.ToLower().Replace("main.window.position=", string.Empty);
                                        int xPos = Convert.ToInt32(main_wnd_pos.Substring(0, main_wnd_pos.IndexOf(",")));
                                        int yPos = Convert.ToInt32(main_wnd_pos.Substring(main_wnd_pos.IndexOf(",") + 1));
                                        _location = new Point(xPos, yPos);
                                    }
                                    else if (line.StartsWith("main.window.always-on-top="))
                                        _alwaysOnTop = Convert.ToBoolean(int.Parse(line.ToLower().Replace("main.window.always-on-top=", string.Empty)));
                                    else if (line.StartsWith("main.system.command-prefix="))
                                        _sysCmdPrefix = line.ToLower().Replace("main.system.command-prefix=", string.Empty);
                                    else if (line.StartsWith("main.system.buffer-length="))
                                        _bufferLength = Convert.ToInt32(line.ToLower().Replace("main.system.buffer-length=", string.Empty));

                                    break;
                            }
                            break;
                    }
                }

                if (mh != MenuHeader.Setup)
                    _iniLines.Add(line);

                line = sr.ReadLine();
            }
            Application.EnableVisualStyles();

            sr.Close();
        }

        public void Save()
        {
            StreamWriter sw = new StreamWriter(INI_FILENAME);
            foreach (string iniLine in _iniLines)
            {
                sw.WriteLine(iniLine);
            }

            sw.WriteLine("[setup]");
            sw.WriteLine("#this will reflect the initial position of the window. The will be updated to the last position before you close WinCommand.");
            sw.WriteLine("main.window.position=" + _location.X + "," + _location.Y);
            sw.WriteLine("#set if it will be always on top or not (configurable by the app through file menu)");
            sw.WriteLine("main.window.always-on-top=" + Convert.ToInt16(_alwaysOnTop));
            sw.WriteLine("#this is the prefix that will be used to some internal commands and to the variable recognition");
            sw.WriteLine("main.system.command-prefix=" + this._sysCmdPrefix);
            sw.WriteLine("#buffer length of the console wrapper. This value work for me for years...so...");
            sw.WriteLine("main.system.buffer-length=" + this._bufferLength);

            sw.Close();
        }
    }
}
