
Ejemplo de archivo WinCommand.ini
Las variables de entorno definidas el sector correspondiente se pueden utilizar en la definici�n de los paths de las
aplicaciones. La variable WCMD-HOME estar� SIEMPRE definida y apuntar� a la carpeta de primer nivel del directorio
desde donde se ejecute la aplicaci�n.
Ej.: 

[applications]
CLisp|$WCMD-HOME\bin\clisp\full\lisp.exe|-M $WCMD-HOME\bin\clisp\full\lispinit.mem -i "$WCMD-HOME\etc\_clisprc.lisp"|(bye)
CormanLisp|$WCMD-HOME\bin\cormanlisp\clconsole.exe||:quit
Command|cmd||exit

[prompts] -- Not used
CLisp=\[[0-9]+\]>
CormanLisp=\[ \]>
Command=[A-Za-z]:[^/:*?\"<>|]*>

[environment]
BOX-HOME=$WCMD-HOME

[setup]
main.window.position=229,143
main.window.always-on-top=1
main.system.command-prefix=$
main.system.buffer-length=128