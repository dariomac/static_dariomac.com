using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

namespace WinCommand
{
    public class ShellTextBoxConf
    {
        public const string WCMD_HOME = "WCMD-HOME";
        public const string INI_FILENAME = "WinCommand.ini";

        protected Hashtable _envVariables = new Hashtable();
        protected string _sysCmdPrefix;
        protected int _bufferLength;
        protected Dictionary<String, AppConf> _applications = new Dictionary<String, AppConf>();

        public Hashtable EnvVariables
        {
            get
            {
                return _envVariables;
            }
            set
            {
                _envVariables = value;
            }
        }

        public Dictionary<String, AppConf> Applications
        {
            get
            {
                return _applications;
            }
            set
            {
                _applications = value;
            }
        }

        public string SysCmdPrefix
        {
            get
            {
                return _sysCmdPrefix;
            }
            set
            {
                if (_sysCmdPrefix == value)
                    return;
                _sysCmdPrefix = value;
            }
        }
        public int BufferLength
        {
            get
            {
                return _bufferLength;
            }
            set
            {
                if (_bufferLength == value)
                    return;
                _bufferLength = value;
            }
        }

        public static string MakeWCMD_HOME()
        {
            string WCMD_DRIVE = AppDomain.CurrentDomain.BaseDirectory.Split('\\')[0];
            string WCMD_FOLDER = AppDomain.CurrentDomain.BaseDirectory.Split('\\')[1];

            return WCMD_DRIVE + "\\" + WCMD_FOLDER;
        }
    }
}
