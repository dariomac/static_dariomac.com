﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ClojureBox
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (System.Environment.GetEnvironmentVariable("ACB_HOME") == null)
                MessageBox.Show(String.Format("You must set ACB_HOME Environment Variable with ACB installation path as value (possibly {0}).", AppDomain.CurrentDomain.BaseDirectory));
            else
                Application.Run(new frmACB());
        }
    }
}
