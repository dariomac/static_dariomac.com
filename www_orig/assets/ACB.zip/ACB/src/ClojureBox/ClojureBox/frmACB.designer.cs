﻿namespace ClojureBox
{
    partial class frmACB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmACB));
            this.cm = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.SuspendLayout();
            // 
            // cm
            // 
            this.cm.Name = "contextMenuStrip1";
            this.cm.Size = new System.Drawing.Size(61, 4);
            // 
            // frmACB
            // 
            this.AllowDrop = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(104, 90);
            this.ContextMenuStrip = this.cm;
            this.ControlBox = false;
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmACB";
            this.Opacity = 0.8;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "ACB";
            this.TopMost = true;
            this.TransparencyKey = System.Drawing.Color.White;
            this.Load += new System.EventHandler(this.frmACB_Load);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.frmACB_MouseUp);
            this.MouseEnter += new System.EventHandler(this.frmACB_MouseEnter);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.frmACB_DragDrop);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.frmACB_MouseDown);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.frmACB_DragEnter);
            this.MouseLeave += new System.EventHandler(this.frmACB_MouseLeave);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmACB_FormClosing);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmACB_MouseMove);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip cm;
    }
}